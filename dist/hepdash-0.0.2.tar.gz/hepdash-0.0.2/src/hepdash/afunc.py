def func():
    print("Hello world")