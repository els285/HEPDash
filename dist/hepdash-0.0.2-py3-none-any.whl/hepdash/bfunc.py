print("Leo McGee")
